package com.ficr.edu.bancoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulatesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulatesteApplication.class, args);
	}

}
